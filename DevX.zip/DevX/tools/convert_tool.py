import google.generativeai as genai
import os
from PromptHub import load_prompt
os.environ["GOOGLE_API_KEY"] ="AIzaSyArYq9kel4SMUDYNpFhhuRq40YJQuICNwM"
class DevXConvert:
    def __init__(self, api_key: str = None):
        genai.configure(api_key="AIzaSyArYq9kel4SMUDYNpFhhuRq40YJQuICNwM")
        if api_key:
            genai.configure(api_key="AIzaSyArYq9kel4SMUDYNpFhhuRq40YJQuICNwM")
        self.model = genai.GenerativeModel("gemini-2.0-flash")

    def interpret_pipeline_structure(self, file_content: str, source_platform: str, target_platform: str) -> str:
        """Interprets pipeline structure for platform transformation."""
        template = load_prompt("interpret_pipeline_structure_prompt.txt")
        prompt = template.format(
            file_content=file_content,
            source_platform=source_platform,
            target_platform=target_platform
        )
        response = self.model.generate_content(prompt)
        return response.text.strip()

    def convert_azure_to_jenkins(self, file_content: str, os: str) -> str:
        """Converts Azure DevOps pipeline YAML to Jenkins pipeline syntax."""
        print("In convert_azure_to_jenkins method")
        template = load_prompt("convert_azure_to_jenkins_prompt.txt")
        prompt = template.format(file_content=file_content, os=os)
        print("Prompt:", prompt)
        response = self.model.generate_content(prompt)
        return response.text.strip()

    def convert_jenkins_to_azure(self, file_content: str, os: str) -> str:
        """Converts Jenkins pipeline YAML to Azure DevOps format."""
        template = load_prompt("convert_jenkins_to_azure_prompt.txt")
        prompt = template.format(file_content=file_content, os=os)
        response = self.model.generate_content(prompt)
        print("response.text ",response.text)
        return response.text.strip()

# 🔧 Tool function for pipeline conversion
def convert_pipeline_tool(pipeline_yaml: str, source_tech: str, target_tech: str, input_os: str) -> str:
    print("🔧 In convert_pipeline_tool function")
    print("source_tech:", source_tech)
    print("target_tech:", target_tech)

    converter = DevXConvert()
   
    source = source_tech.lower().replace(" ", "").replace("_", "")
    target = target_tech.lower().replace(" ", "").replace("_", "")
    if "azure" in source and "jenkins" in target:
        return converter.convert_azure_to_jenkins(pipeline_yaml, input_os)
    elif "jenkins" in source and "azure" in target:
        return converter.convert_jenkins_to_azure(pipeline_yaml, input_os)
    else:
        raise ValueError(f"Unsupported conversion from {source_tech} to {target_tech}")