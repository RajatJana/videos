# streamlit_app.py

import streamlit as st
from agents.convert_agent import run_conversion
import asyncio

st.set_page_config(page_title="Pipeline Converter", layout="centered")
st.title("🔄 DevOps Pipeline Converter (Gemini Powered)")

st.markdown("---")

# --- File Upload ---
uploaded_file = st.file_uploader("📄 Upload your pipeline YAML file", type=["yml", "yaml", "json", "txt"])

# --- Platform Selections ---
col1, col2 = st.columns(2)
with col1:
    source_platform = st.selectbox("Source Platform", ["Azure DevOps YAML", "Jenkins"])
with col2:
    target_platform = st.selectbox("Target Platform", ["Jenkins", "Azure DevOps YAML"])

# --- OS Selection ---
os_choice = st.selectbox("Target OS", ["linux", "windows"])

# --- Submit Button ---
if st.button("🚀 Convert Pipeline"):
    if not uploaded_file:
        st.warning("Please upload a YAML file first.")
    elif source_platform == target_platform:
        st.warning("Source and target platforms must be different.")
    else:
        file_content = uploaded_file.read().decode("utf-8")
        
        with st.spinner("Converting pipeline..."):
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            converted = loop.run_until_complete(
                run_conversion(
                    source_tech=source_platform,
                    target_tech=target_platform,
                    pipeline_code=file_content,
                    input_os=os_choice
                )
            ) 

        # --- Results ---
        st.markdown("## ✅ Conversion Result")
        with st.expander("🛠️ Converted Pipeline", expanded=True):
            st.code(converted, language="yaml")
            st.success(f"Your pipeline has been converted from {source_platform} to {target_platform}! ✨")
