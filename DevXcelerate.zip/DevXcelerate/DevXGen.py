import os
import shutil
import tempfile
import git
import google.generativeai as genai
from PromptHub import load_prompt

# ====== CONFIG ======
genai.configure(api_key="AIzaSyApsAGYqoenhbUQ0Zw2tgzMWU_T-IaNHaQ")  # <-- Replace with your actual API key
model = genai.GenerativeModel("gemini-2.0-flash")

# ====== STEP 1: Clone GitHub Repo ======
def clone_repo(repo_link):
    temp_dir = tempfile.mkdtemp()
    try:
        git.Repo.clone_from(repo_link, temp_dir)
        return temp_dir, None
    except Exception as e:
        shutil.rmtree(temp_dir)
        return None, str(e)

# ====== STEP 2: Extract Representative Files ======
def collect_key_files(project_path, max_files=20, max_chars=5000):
    important_files = []
    extensions = ('.xml', '.gradle', '.txt', '.go', '.sln', '.mod', '.kts', '.yml', '.yaml', 'Dockerfile', '.tf', '.json', '.properties')
    
    for root, dirs, files in os.walk(project_path):
        for file in files:
            filepath = os.path.join(root, file)
            if file.endswith(extensions) or file == 'Dockerfile':
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():
                            important_files.append({
                                "name": file,
                                "path": filepath,
                                "content": content[:max_chars]
                            })
                            if len(important_files) >= max_files:
                                return important_files
                except Exception:
                    continue
    return important_files

# ====== STEP 3: Detect Tech ======
def detect_tech(files_data, repo_link):
    file_texts = "\n\n".join([f"File: {f['path']}\nContent:\n{f['content']}" for f in files_data])
    template = load_prompt("detect_tech_prompt.txt")
    prompt = template.format(files_data=files_data, repo_link=repo_link, file_texts=file_texts)
    response = model.generate_content(prompt)
    return response.text

# ====== STEP 4: Generate CI/CD Pipeline Specification ======
def generate_spec(detected_info, repo_link, user_additions):
    template = load_prompt("generate_spec_prompt.txt")
    prompt = template.format(detected_info=detected_info, repo_link=repo_link, user_additions=user_additions or "None")
    response = model.generate_content(prompt)
    return response.text

# ====== STEP 5: Generate CI/CD Pipeline ======
def generate_pipeline(detected_info, repo_link, user_additions, ci_cd_tool, specification, os):
    template = load_prompt("generate_pipeline_prompt.txt")
    prompt = template.format(detected_info=detected_info, repo_link=repo_link, user_additions=user_additions or "None", ci_cd_tool=ci_cd_tool, specification=specification, os=os)
    response = model.generate_content(prompt)
    return response.text


# ====== Optional Cleanup ======
def cleanup(path):
    try:
        shutil.rmtree(path)
    except Exception:
        pass