import google.generativeai as genai
from PromptHub import load_prompt

genai.configure(api_key="AIzaSyApsAGYqoenhbUQ0Zw2tgzMWU_T-IaNHaQ")  # Replace with your Gemini API key
model = genai.GenerativeModel("gemini-2.0-flash")


def interpret_pipeline_structure(file_content: str, source_platform: str, target_platform: str):
    template = load_prompt("interpret_pipeline_structure_prompt.txt")
    prompt = template.format(file_content=file_content, source_platform=source_platform, target_platform=target_platform)
    response = model.generate_content(prompt)
    return response.text.strip()

def convert_azure_to_jenkins(file_content: str, os: str) -> str:
    template = load_prompt("convert_azure_to_jenkins_prompt.txt")
    prompt = template.format(file_content=file_content, os=os)
    response = model.generate_content(prompt)
    return response.text.strip()

def convert_jenkins_to_azure(file_content: str, os: str ) -> str:
    template = load_prompt("convert_jenkins_to_azure_prompt.txt")
    prompt = template.format(file_content=file_content, os=os)
    response = model.generate_content(prompt)
    return response.text.strip()