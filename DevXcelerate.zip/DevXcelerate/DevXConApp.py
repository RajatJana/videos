import streamlit as st
from DevXCon import convert_azure_to_jenkins, convert_jenkins_to_azure, interpret_pipeline_structure, convert
from AgentConnect import llm_rerun  # Import the feedback processing function
import re
from ExpertApp import show as expert_show
from Pipeline_Converter import run_conversion
import asyncio

def render_progress_bar(current_step):
    steps = ["Source Upload", "Review & Refine", "Final Output"]

    # Track completion status based on actual outputs  
    completed_steps = []  
    if st.session_state.get('file_content'):  
        completed_steps.append(1)  
    if st.session_state.get('pipeline_code') and st.session_state.get('user_validated'):  
        completed_steps.append(2)  
    if st.session_state.get('final_code'):  
        completed_steps.append(3)  

    if not st.session_state.get('file_content'):  
        current_step = 1  
    elif not st.session_state.get('pipeline_code') or not st.session_state.get('user_validated'):  
        current_step = 2  
    elif not st.session_state.get('final_code'):  
        current_step = 3  
    else:  
        current_step = 3  

    css = """  
    <style>  
       .progress-container {  
           display: flex;  
           align-items: flex-start;  
           justify-content: space-between;  
           width: 90%;  
           margin: 30px auto;  
           padding: 0;  
       }  
       .step-item {  
           display: flex;  
           flex-direction: column;  
           align-items: center;  
           text-align: center;  
           flex: 1;  
           position: relative;  
           font-size: 12px;  
        }  
        .step-item:not(:last-child)::after {  
            content: '';  
            position: absolute;  
            top: 17px;  
            left: 50%;  
            width: 100%;  
            height: 3px;  
            background-color: #e9ecef;  
            z-index: 1;  
        }  
        .step-circle {  
            width: 30px;  
            height: 30px;  
            border-radius: 50%;  
            background-color: #ffffff;  
            border: 3px solid #e9ecef;  
            color: #000000 !important;  
            display: flex;  
            justify-content: center;  
            align-items: center;  
            font-weight: bold;  
            font-size: 1rem;  
            margin-bottom: 10px;  
            position: relative;  
            z-index: 2;  
       }  
       .step-label {  
           margin-top: 3px;  
           word-break: keep-all;  
           font-weight: 500;  
       }  
       .step-item.completed .step-circle {  
           background-color: #28a745;  
           border-color: #28a745;  
           color: white !important;  
       }  
       .step-item.completed .step-label {  
       }  
       .step-item.completed::after {  
           background-color: #28a745;  
       }  
       .step-item.active .step-circle {  
           border-color: #1195CE;  
           background-color: #1195CE;  
           color: white !important;  
       }  
       .step-item.active .step-label {  
           font-weight: bold;  
       }  
    </style>  
    """  
    
    html = '<div class="progress-container">'  
    for i, step_name in enumerate(steps):  
        step_num = i + 1  
        status_class = ""  
        circle_content = str(step_num)  
          
        if step_num in completed_steps:  
            status_class = "completed"  
            circle_content = "✓"  
        elif step_num == current_step:  
            status_class = "active"  
          
        html += f'<div class="step-item {status_class}">'  
        html += f'  <div class="step-circle">{circle_content}</div>'  
        html += f'  <div class="step-label">{step_name}</div>'  
        html += '</div>'  
    html += '</div>'  
    st.markdown(css + html, unsafe_allow_html=True)

def is_conversion_supported(input_tech, output_tech):
    # Define supported conversions
    supported_conversions = [
        ("Azure DevOps YAML", "Jenkins"),
        ("Jenkins", "Azure DevOps YAML")
        # Add more supported conversions here as you implement them
    ]
    return (input_tech, output_tech) in supported_conversions

def show():
    # Initialize session state
    if 'page' not in st.session_state:
        st.session_state.page = 1
    if 'desc' not in st.session_state:
        st.session_state.desc = None
    if 'pipeline_code' not in st.session_state:
        st.session_state.pipeline_code = None
    if 'final_code' not in st.session_state:
        st.session_state.final_code = None
    if 'file_content' not in st.session_state:
        st.session_state.file_content = None
    if 'uploaded_file' not in st.session_state:
        st.session_state.uploaded_file = None
    if 'user_validated' not in st.session_state:
        st.session_state.user_validated = False
    if 'feedback_mode' not in st.session_state:
        st.session_state.feedback_mode = False
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    if 'current_feedback' not in st.session_state:
        st.session_state.current_feedback = ""
    if 'mod_chat_history' not in st.session_state:
        st.session_state.mod_chat_history = []
    if 'mod_pipeline_chat_open' not in st.session_state:
        st.session_state.mod_pipeline_chat_open = False
    if 'refine_chat' not in st.session_state:
        st.session_state.refine_chat = False

    st.markdown("<h2 style='color: #1195CE;'>✨ Pipeline Converter</h2>", unsafe_allow_html=True)  
    
    # Show progress bar with current page  
    render_progress_bar(st.session_state.page)  

    # Technology selection  
    disabled_select = st.session_state.page > 1  

    with st.container(border=True):  
        col1, col2, col3 = st.columns(3)  
        with col1:    
            input_tech = st.selectbox(  
                "**Source Technology**",   
                ["Azure DevOps YAML", "Jenkins", "AWS CodePipeline(⌛)"],   
                index=None,   
                placeholder="Select source platform",  
                disabled=disabled_select,  
                help="The technology of your current pipeline"  
            )    
        with col2:    
            output_tech = st.selectbox(  
                "**Target Technology**",   
                ["Azure DevOps YAML", "Jenkins", "AWS CodePipeline(⌛)"],   
                index=None,   
                placeholder="Select target platform",  
                disabled=disabled_select,  
                help="The technology you want to convert to"  
            )    
        with col3:    
            os = st.selectbox(  
                "**Target OS**",   
                ["Linux", "Windows"],   
                index=None,   
                placeholder="Select operating system",  
                disabled=disabled_select,  
                help="The operating system for the target pipeline"  
            )  

    # Page 1: File Upload  
    if st.session_state.page == 1:  
        with st.container(border=True):  
            st.write("### Upload your pipeline file:")  
              
            if input_tech is None or output_tech is None or os is None:  
                st.info("ℹ️ Please select all conversion settings above")  
            elif not is_conversion_supported(input_tech, output_tech):  
                st.error(f"⚠️ Conversion from {input_tech} to {output_tech} is not supported yet")  
            else:  
                uploaded_file = st.file_uploader(                      
                    "**Choose a pipeline file**",     
                    type=None,  
                    key="file_uploader",  
                    label_visibility="collapsed"
                    )  
              
                if uploaded_file is not None and uploaded_file != st.session_state.uploaded_file:  
                    st.session_state.uploaded_file = uploaded_file  
                    try:  
                        st.session_state.file_content = uploaded_file.getvalue().decode("utf-8")  
                        st.rerun()  # Update progress bar immediately  
                    except Exception as e:  
                        st.error(f"Error reading file: {e}")  
                        st.session_state.file_content = None  
                        st.session_state.uploaded_file = None  
          
        if st.session_state.file_content:  
            st.write("#### File Preview:")  
            st.code(st.session_state.file_content, language="yaml")
            st.session_state.desc = interpret_pipeline_structure(st.session_state.file_content, input_tech, output_tech)  
            #st.code(st.session_state.desc, language="yaml")  
            cols = st.columns([1, 1, 1.2, 1, 1])  
            with cols[4]:  
                if st.button("▶  Convert ", key="next1", use_container_width=True):  
                    st.session_state.page = 2  
                    st.rerun()  

    # Page 2: Draft Conversion with Feedback or Validation
    elif st.session_state.page == 2:  
        st.write("#### Draft Converted Pipeline:")  
          
        if st.session_state.pipeline_code is None:  
            if not input_tech or not output_tech:  
                st.error("Please select both Input Tech and Output Tech")  
            elif not is_conversion_supported(input_tech, output_tech):  
                st.error(f"{input_tech} to {output_tech} conversion is not supported yet")  
            else:  
                with st.spinner("Generating Draft Conversion..."):  
                    try:  
                        # st.session_state.pipeline_code = convert(st.session_state.file_content,input_tech, output_tech, os)  
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)

                        st.session_state.pipeline_code = loop.run_until_complete(
                            run_conversion(
                                source_tech=input_tech,
                                target_tech=output_tech,
                                pipeline_code=st.session_state.file_content,
                                input_os=os
                            )
                        ) 
                        st.rerun()  # Update progress bar immediately  
                    except Exception as e:  
                        st.error(f"Conversion failed: {e}")  
          
        if st.session_state.pipeline_code:  
            if not st.session_state.feedback_mode:
                # Show the initial draft with options to validate or provide feedback
                st.code(st.session_state.pipeline_code, language="yaml")
                
                cols = st.columns([1, 1, 1, 1, 1, 1, 1])
                with cols[0]:
                    if st.button("◀ Back", key="back_btn_1", use_container_width=True):
                        st.session_state.page = 1
                        st.rerun()
                with cols[2]:
                    if st.button("🧠 Refine", use_container_width=True):
                        st.session_state.refine_chat = True
                        st.session_state.feedback_mode = False
                with cols[4]:
                    if st.button("💬 Request", key="feedback_btn", use_container_width=True):
                        st.session_state.feedback_mode = True
                        st.session_state.refine_chat = False
                        st.rerun()
                with cols[6]:
                    if st.button("✅ Confirm", type="primary", key="valid_btn", use_container_width=True):
                        st.session_state.user_validated = True
                        st.session_state.final_code = st.session_state.pipeline_code
                        st.session_state.page = 3
                        st.rerun()

                if st.session_state.refine_chat:
                    expert_show()

            else:
                # Feedback mode - chat-like interface
                st.code(st.session_state.pipeline_code, language="yaml")
                
                # Display chat history
                with st.expander("**Conversation History**"):
                    #st.write("**Conversation History**")
                    if not st.session_state.chat_history:
                        st.write("No conversation history yet.")
                    else:
                        for msg in st.session_state.chat_history:
                            if msg['role'] == 'user':
                                st.markdown(f"**🧑‍💻 You:** {msg['content']}")
                            else:
                                st.markdown(f"**🤖 Assistant:** {msg['content']}")
                
                # Feedback input
                with st.container(border=True):
                    feedback = st.text_area(
                        "Enter your request for changes:",
                        value=st.session_state.current_feedback,
                        key="feedback_input"
                    )
                    
                    cols =st.columns([4,1,1,1,1,1,2])
                    with cols[0]:

                        if st.button("Request"):
                            if feedback.strip():
                                st.session_state.current_feedback = feedback
                                
                                with st.spinner("Processing your request..."):
                                    try:
                                        # Prepare the chat history in the format expected by llm_rerun
                                        chat_history = [
                                            {"user": msg["content"], "response": msg["content"] if msg["role"] == "assistant" else ""}
                                            for msg in st.session_state.chat_history
                                            if msg["role"] == "assistant"  # Only include assistant responses in history
                                        ]
                                        
                                        # Process feedback and update conversion
                                        response = llm_rerun(
                                            st.session_state.pipeline_code, 
                                            chat_history,
                                            feedback
                                        )
                                        
                                        # Extract the code from the response (assuming it contains markdown with code blocks)
                                        code_match = re.search(r"```(?:yaml|json|[\w]*)\n(.*?)```", response, re.DOTALL)
                                        updated_output = code_match.group(1).strip() if code_match else response
                                        
                                        # Update the conversion output
                                        st.session_state.pipeline_code = updated_output
                                        
                                        # Add to chat history
                                        st.session_state.chat_history.extend([
                                            {"role": "user", "content": feedback},
                                            {"role": "assistant", "content": response}
                                        ])
                                        
                                        st.rerun()
                                    except Exception as e:
                                        st.error(f"Error processing feedback: {str(e)}")
                    with cols[6]:
                        if st.button("Exit",use_container_width=True):
                            st.session_state.feedback_mode = False
                            st.rerun()
                
                # Validation option after feedback
                cols = st.columns([1, 1, 1.2, 1, 1])
                with cols[4]:
                    if st.button("✅ Confirm", type="primary", key="valid_btn_feedback", use_container_width=True):
                        st.session_state.user_validated = True
                        st.session_state.final_code = st.session_state.pipeline_code
                        st.session_state.page = 3
                        st.rerun()

    # Page 3: Final Pipeline (unchanged from original)
    elif st.session_state.page == 3:  
        st.write("#### Final Pipeline:")  
          
        if st.session_state.final_code is None:  
            # For now just use the validated conversion output as final code
            st.session_state.final_code = st.session_state.pipeline_code
            st.rerun()  
        
        if st.session_state.final_code:  
            st.code(st.session_state.final_code, language="yaml")  

            # Determine appropriate file name and mime type
            if output_tech == "Azure DevOps YAML":  
                file_name = "azure_pipeline.yml"  
                mime_type = "text/yaml"  
            elif output_tech == "Jenkins":  
                file_name = "Jenkinsfile"  
                mime_type = "text/plain"  
            else:
                file_name = "pipeline.yml"
                mime_type = "text/yaml"

            cols = st.columns([1, 1, 1.2, 1, 1])  
            with cols[0]:  
                if st.button("◀ Back", key="back_btn_2"):  
                    st.session_state.page = 2  
                    st.rerun()  
            with cols[2]:  
                st.download_button(  
                    label="💾 Download Pipeline",  
                    data=st.session_state.final_code,  
                    file_name=file_name,  
                    mime=mime_type  
                )   

            with cols[4]:
                if st.button("✏️ Connect", use_container_width=True):
                    st.session_state.mod_pipeline_chat_open = True

            if st.session_state.mod_pipeline_chat_open:
                st.markdown("### ✨ Connect with the Assistant")

                # Suggestions
                suggestions = [
                    "Explain the pipeline",
                    "Give Setup Instructions",
                    "Explain each stage with comments",
                    "Review the pipeline"
                ]
                selected_suggestion = st.selectbox("Quick Suggestions", [""] + suggestions)
                user_mod_input = st.text_area("💬 Ask the Assistant about the code", value=selected_suggestion, key="user_mod_input_area")

                if st.button("🔁 Ask"):
                    original_code = st.session_state.final_code
                    #last_response = st.session_state.mod_chat_history[-1]['response'] if st.session_state.mod_chat_history else st.session_state.pipeline_code
                    chat_history = st.session_state.mod_chat_history
                    with st.spinner("Assistant is processing your input..."):
                        response = llm_rerun(original_code, chat_history, user_mod_input)
                        st.session_state.mod_chat_history.append({
                            "user": user_mod_input,
                            "response": response
                        })
                    st.rerun()

            for i, chat in enumerate(st.session_state.mod_chat_history):
                st.markdown(f"#### 🧑‍💻 You: {chat['user']}")
                with st.expander(f"🤖 Response {i+1}", expanded=True):
                        st.markdown(chat['response'])

if __name__ == "__main__":
    show()