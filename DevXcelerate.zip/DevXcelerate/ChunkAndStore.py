from langchain.text_splitter import MarkdownHeaderTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from langchain.docstore.document import Document

# Load your markdown file
with open("standard_document.md", "r", encoding="utf-8") as f:
    md_text = f.read()

# Define how to split based on Markdown headers
splitter = MarkdownHeaderTextSplitter(headers_to_split_on=[
    ("##", "h1"),
    ("###", "h2"),
    ("####", "h3"),
])

# Get structured documents
docs: list[Document] = splitter.split_text(md_text)

# Optionally print to verify structure
for doc in docs[:5]:
    print(f"-----\nMetadata: {doc.metadata}\nContent:\n{doc.page_content}\n")

# Embedding model
embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

# Vector store using FAISS
vectorstore = FAISS.from_documents(docs, embedding_model)

# Save to local disk
vectorstore.save_local("pipeline_faiss_index")