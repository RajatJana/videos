import streamlit as st
import streamlit.components.v1 as components
import docx
import json
import pandas as pd
import re
from DevXGen import clone_repo, collect_key_files, detect_tech, generate_spec, cleanup, generate_pipeline
from AgentConnect import llm_rerun
from ExpertApp import show as expert_show

def render_text_progress_bar(current_step):
    steps = ["Extract Details","Create Specification","Generate Code"]

    step1_completed = bool(st.session_state.get('extracted_data'))
    step2_completed = bool(st.session_state.get('specification'))
    step3_completed = bool(st.session_state.get('pipeline_code'))

    completed_steps = []
    if step1_completed:
        completed_steps.append(1)
    if step2_completed:
        completed_steps.append(2)
    if step3_completed:
        completed_steps.append(3)

    if not step1_completed:
        current_step = 1
    elif not step2_completed:
        current_step = 2
    elif not step3_completed:
        current_step = 3
    else:
        current_step = 3
    
    css = """
    <style>
       .progress-container {
           display: flex;
           align-items: flex-start;
           justify-content: space-between;
           width: 90%;
           margin: 30px auto;
           padding: 0;
       }
       .step-item {
           display: flex;
           flex-direction: column;
           align-items: center;
            text-align: center;
            flex: 1;
            position: relative;
            font-size: 12px;
        }
        .step-item:not(:last-child)::after {
            content: '';
            position: absolute;
            top: 17px;
            left: 50%;
            width: 100%;
            height: 3px;
            background-color: #e9ecef;
            z-index: 1;
        }
        .step-circle {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #ffffff;
            border: 3px solid #e9ecef;
            color: #000000 !important;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
            font-size: 1rem;
            margin-bottom: 10px;
            position: relative;
            z-index: 2;
       }
       .step-label {
           margin-top: 3px;
           word-break: keep-all;
           font-weight: 500;

       }
       .step-item.completed .step-circle {
           background-color: #28a745;
           border-color: #28a745;
           color: white !important;
           font-size: 1rem;
       }
       .step-item.completed .step-label {
       }
       .step-item.completed::after {
           background-color: #28a745;
       }
       .step-item.active .step-circle {
           border-color: #1195CE;
           background-color: #1195CE;
           color: white !important;
       }
       .step-item.active .step-label {
           font-weight: bold;
       }
    </style>
    """
    
    html = '<div class="progress-container">'
    for i, step_name in enumerate(steps):
        step_num = i + 1
        status_class = "pending"
        circle_content = str(step_num)
        if step_num in completed_steps:
            status_class = "completed"
            circle_content = "✓"
        elif step_num == current_step:
            status_class = "active"

        html += f'<div class="step-item {status_class}">'
        html += f'  <div class="step-circle">{circle_content}</div>'
        html += f'  <div class="step-label">{step_name}</div>'
        html += '</div>'
    html += '</div>'
    st.markdown(css + html, unsafe_allow_html=True)

def render_file_progress_bar(current_step):
    steps = ["JSON Spec File Generation", "Review JSON Spec", "Jenkins File"]
    total_steps = len(steps)
    
    css = """
    <style>
       .progress-container {
           display: flex;
           align-items: flex-start;
           justify-content: space-between;
           width: 90%;
           margin: 30px auto;
           padding: 0;
       }
       .step-item {
           display: flex;
           flex-direction: column;
           align-items: center;
            text-align: center;
            flex: 1;
            position: relative;
            font-size: 12px;
        }
        .step-item:not(:last-child)::after {
            content: '';
            position: absolute;
            top: 17px;
            left: 50%;
            width: 100%;
            height: 3px;
            background-color: #e9ecef;
            z-index: 1;
        }
        .step-circle {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #ffffff;
            border: 3px solid #e9ecef;
            color: #000000 !important;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
            font-size: 1rem;
            margin-bottom: 10px;
            position: relative;
            z-index: 2;
       }
       .step-label {
           margin-top: 3px;
           word-break: keep-all;
           font-weight: 500;
       }
       .step-item.completed .step-circle {
           background-color: #28a745;
           border-color: #28a745;
           color: white !important;
           font-size: 1rem;
       }
       .step-item.completed .step-label {
       }
       .step-item.completed::after {
           background-color: #28a745;
       }
       .step-item.active .step-circle {
           border-color: #1195CE;
           background-color: #1195CE;
           color: white !important;
       }
       .step-item.active .step-label {
           font-weight: bold;
       }
    </style>
    """
    
    html = '<div class="progress-container">'
    for i, step_name in enumerate(steps):
        step_num = i + 1
        status_class = "pending"
        circle_content = str(step_num)
        if step_num < current_step:
            status_class = "completed"
            circle_content = "✓"
        elif step_num == current_step:
            status_class = "active"
        html += f'<div class="step-item {status_class}">'
        html += f'  <div class="step-circle">{circle_content}</div>'
        html += f'  <div class="step-label">{step_name}</div>'
        html += '</div>'
    html += '</div>'
    st.markdown(css + html, unsafe_allow_html=True)

def is_generation_supported(tech):
    supported_generation = [
        "Azure DevOps YAML", "Jenkins"
        ]
    return (tech) in supported_generation

def show():
    if 'mod_chat_history' not in st.session_state:
        st.session_state.mod_chat_history = []
    if 'mod_pipeline_chat_open' not in st.session_state:
        st.session_state.mod_pipeline_chat_open = False
    if 'refine_chat' not in st.session_state:
        st.session_state.refine_chat = False
    if "project_path" not in st.session_state:
        st.session_state.project_path = None
    if "extracted_data" not in st.session_state:
        st.session_state.extracted_data = None
    if "user_additions" not in st.session_state:
        st.session_state.user_additions = ""
    if 'step' not in st.session_state:
        st.session_state.step = 1
    if 'input_method' not in st.session_state:
        st.session_state.input_method = "text"
    if 'repo_link' not in st.session_state:
        st.session_state.repo_link = ""
    if 'repo' not in st.session_state:
        st.session_state.repo = ""
    if 'extracted_details' not in st.session_state:
        st.session_state.extracted_details = None
    if 'extracted_data' not in st.session_state:
        st.session_state.extracted_data = None
    if 'specification' not in st.session_state:
        st.session_state.specification = None
    if 'pipeline_code' not in st.session_state:
        st.session_state.pipeline_code = None
    if 'active_step' not in st.session_state:
        st.session_state.active_step = 1
    if 'show_progress' not in st.session_state:
        st.session_state.show_progress = True
    if 'stages' not in st.session_state:
        st.session_state.stages = [{"stage": "", "tool": ""}]

    st.markdown("<h2 style='color: #1195CE;'>✨ Pipeline Generator</h2>", unsafe_allow_html=True)
    if st.session_state.get('show_progress'):
        if st.session_state.input_method == "text":
            render_text_progress_bar(st.session_state.step)
        elif st.session_state.input_method == "file":
            render_file_progress_bar(st.session_state.step)

        disabled_select = st.session_state.active_step > 1

        with st.container(border=True):
            col1, col2 = st.columns(2)
            with col1:  
                tech = st.selectbox(
                    "**🧩 Pipeline Technology**", 
                    ["Azure DevOps YAML", "Jenkins", "AWS CodePipeline(⌛)"], 
                    index=None, 
                    placeholder="Select Pipeline Technology",
                    disabled=disabled_select,
                    help="The Desired CI/CD Pipeline Technology"
                ) 
            with col2:  
                os = st.selectbox(
                    "**🖥️ OS**", 
                    ["Linux", "Windows"], 
                    index=None, 
                    placeholder="Select Operating System",
                    disabled=disabled_select,
                    help="The operating system where pipeline will be running"
                )

    # Input Area
    # input_col1, or_col, input_col2 = st.columns([1,0.1,1], gap="small")
    # with input_col1:
    #     if st.button("✍️ Enter Pipeline Description", use_container_width=True):
    #         st.session_state.input_method = "text"
    #         st.session_state.repo_link = ""
    #         st.session_state.repo = ""
    #         st.session_state.show_progress = True
    #         st.session_state.extracted_data = None
    #         st.session_state.extracted_details = None
    #         st.session_state.specification = None
    #         st.session_state.pipeline_code = None
    #         st.session_state.active_step = 1
    #         st.rerun()
    # with or_col:
    #     st.markdown("<div style='text-align: center; padding-top: 10px; font-weight: bold;'>OR</div>", unsafe_allow_html=True)
    # with input_col2:
    #     if st.button("📁 Upload File", use_container_width=True):
    #         st.session_state.input_method = "file"
    #         st.session_state.repo_link = ""
    #         st.session_state.repo = ""
    #         st.session_state.show_progress = True
    #         st.session_state.extracted_data = None
    #         st.session_state.extracted_details = None
    #         st.session_state.specification = None
    #         st.session_state.pipeline_code = None
    #         st.session_state.active_step = 1
    #         st.rerun()

    # Text input area (shown when text input method is selected)
    if st.session_state.input_method == "text":

        if tech is None or os is None:
            st.info("Please select Pipeline Technology & OS")
        elif not is_generation_supported(tech):
            st.error(f"{tech} generation is not supported yet")
        else:
            st.markdown('<div class="narrow-textarea">', unsafe_allow_html=True)
            text_area_key = f"pipeline_input_text_{st.session_state.get('text_reset_counter', 0)}"
            repo_key = f"repo_input_{st.session_state.get('text_reset_counter', 0)}"
       
            def on_text_change():
                if st.session_state.get(text_area_key, "") == "":
                    st.session_state.text_reset_counter = st.session_state.get('text_reset_counter', 0) + 1
                    st.session_state.repo_link = ""
                    st.session_state.extracted_data = None
                    st.session_state.extracted_details = None
                    st.session_state.specification = None
                    st.session_state.pipeline_code = None
                    st.session_state.active_step = 1
                    st.rerun()

            # repo = st.text_input(
            #     "Repository Link:",
            #     placeholder="https://github.com/your/repo.git",
            #     value=st.session_state.repo,
            #     key=repo_key
            # )
            repo_link = st.text_input(
                "🔗 GitHub Repository URL:",
                placeholder="https://github.com/your/repo.git",
                value=st.session_state.repo_link,
                key=text_area_key,
                on_change=on_text_change
            )
            st.markdown('</div>', unsafe_allow_html=True)
       
            if repo_link and repo_link!= st.session_state.repo_link:
                st.session_state.repo_link = repo_link
                st.session_state.extracted_data = None
                st.session_state.extracted_details = None
                st.session_state.specification = None
                st.session_state.pipeline_code = None
                st.session_state.active_step = 1
                st.rerun()

            # if repo and repo!= st.session_state.repo:
            #     st.session_state.repo = repo
            #     st.rerun()

    # Process steps based on current active step 
    if st.session_state.repo_link:
        # Step 1: Extraction
        if st.session_state.active_step == 1:
            st.subheader("1. Extract Details")
            
            if not st.session_state.extracted_data:
                with st.spinner("Cloning and analyzing repo..."):
                    project_path, error = clone_repo(repo_link)
                    if error:
                        st.error(f"Failed to clone repository: {error}")
                    elif not project_path:
                        st.warning("Something went wrong.")
                    else:
                        files_data = collect_key_files(project_path)
                        if not files_data:
                            st.warning("No valid config files found for analysis.")
                            cleanup(project_path)
                        else:
                            st.session_state.extracted_data = detect_tech(files_data, repo_link)
                            st.session_state.project_path = project_path
                            st.session_state.repo_link = repo_link
                            st.success("Technology analysis completed!")
                            st.rerun()

            if st.session_state.extracted_data:
                    st.markdown("### 🧾 Tech Stack Analysis")
                    st.code(st.session_state.extracted_data)

                    st.markdown("### ➕ Add Optional Custom CI/CD Instructions")
                    st.session_state.user_additions = st.text_area("Custom instructions (e.g., add SonarQube, secrets scan)", value= st.session_state.user_additions)


            cols = st.columns([1, 1, 1.2, 1, 1])
            with cols[4]:
                    if st.button("▶ Next: Generate Spec", key="next1", use_container_width=True):
                        st.session_state.active_step = 2
                        st.rerun()

            st.subheader("📘 Example Instructions for Common CI/CD Stages")

            col1, col2 = st.columns(2)

            with col1:
                st.markdown("### 🔍 SonarQube Analysis")
                st.code("""Add SonarQube analysis using server URL http://sonarqube.mycompany.com with projectKey=my-app and loginToken=my-token. Publish report to target/sonar-report.""")

                st.markdown("**Required Inputs:**")
                st.markdown("""
            - SonarQube Server URL  
            - Project key  
            - Authentication token  
            - Report path (optional)
            """)

                st.markdown("### ✅ JUnit Testing")
                st.code("""Run JUnit tests after build using Maven Surefire Plugin. Test reports should be stored at target/surefire-reports.""")

                st.markdown("**Required Inputs:**")
                st.markdown("""
            - Test framework (e.g., JUnit, TestNG)  
            - Report directory (e.g., target/surefire-reports)  
            - Optional test parameters
            """)

            with col2:
                st.markdown("### ☁️ Deploy to AWS")
                st.code("""Deploy the application to AWS EC2 using SSH. Use private key stored in AWS Secrets Manager and deploy the WAR to /opt/tomcat/webapps.""")

                st.markdown("**Required Inputs:**")
                st.markdown("""
            - Deployment type (EC2, ECS, Lambda)  
            - Region & credentials method  
            - Artifact path  
            - Deployment location
            """)

                st.markdown("### ☁️ Deploy to Azure")
                st.code("""Deploy to Azure Web App using Azure DevOps publish profile. App name is myapp-azure, and resource group is my-rg.""")

                st.markdown("**Required Inputs:**")
                st.markdown("""
            - Deployment target (Web App, VM, AKS)  
            - App/service name  
            - Resource group  
            - Credentials or publish profile method
            """)

                st.markdown("### ☁️ Deploy to Google Cloud")
                st.code("""Deploy to Google Cloud Run using gcloud CLI. Container image is gcr.io/my-project/myapp:latest.""")

                st.markdown("**Required Inputs:**")
                st.markdown("""
            - Deployment type (Cloud Run, GKE, App Engine)  
            - Container/image path  
            - Project ID & region  
            - Authentication method
            """)

        # Step 2: Specification
        elif st.session_state.active_step == 2:
            st.subheader("2. Generate Specification")           

            if not st.session_state.specification:
#                if st.button("Generate Specification"):
                with st.spinner("Generating Specification..."):
                    st.session_state.specification = generate_spec(
                    st.session_state.extracted_data,
                    st.session_state.repo_link,
                    st.session_state.user_additions
                )
                    st.rerun()
            
            if st.session_state.specification:
                st.write("**🧾Specifications:**")
                st.code(st.session_state.specification, language='markdown')
                
                cols = st.columns([1, 1, 1.2, 1, 1])
                with cols[0]:
                    if st.button("◀ Back", use_container_width=True):
                        st.session_state.active_step = 1
                        st.rerun()
                with cols[2]:
                    st.download_button(
                        label="💾 Download Specification",
                        data=st.session_state.specification,
                        file_name="specification.json",
                        mime="json",
                        use_container_width=True
                    )
                with cols[4]:
                    if st.button("▶ Next: Generate Code", key="next2", use_container_width=True):
                        st.session_state.active_step = 3
                        st.rerun()

        # Step 3: Code Generation
        elif st.session_state.active_step == 3:
            st.subheader("3. Generate Pipeline Code")
            
            # col1, col2 = st.columns([1, 4])
            # with col1:
            #     if st.button("◀ Back"):
            #         st.session_state.active_step = 2
            #         st.rerun()
            
            if not st.session_state.pipeline_code:
                # if st.button("Generate Pipeline Code"):
                 with st.spinner("Generating code..."):
                    st.session_state.pipeline_code = generate_pipeline(
                    st.session_state.extracted_data,
                    st.session_state.repo_link,
                    st.session_state.user_additions,
                    tech,
                    st.session_state.specification,
                    os
                )
                    st.rerun()

            match = re.search(r"```(?:yaml|json|[\w]*)\n(.*?)```", st.session_state.pipeline_code, re.DOTALL)
            if match:
                 clean_code = match.group(1).strip()
            else:
                 clean_code = st.session_state.pipeline_code
            
            if tech == "Azure DevOps YAML":
                file_name = "azure_pipeline.yml"
                mime_type = "text/yaml"
            elif tech == "Jenkins":
                file_name = "Jenkinsfile"
                mime_type = "text/plain"   

            if st.session_state.pipeline_code:
                st.write("**Generated Code:**")
                st.code(st.session_state.pipeline_code, language='yaml')

                cols = st.columns([1, 1, 1, 1, 1, 1, 1])
                with cols[0]:
                    if st.button("◀ Back", use_container_width=True):
                        st.session_state.active_step = 2
                        st.rerun()
                with cols[6]:
                    st.download_button(
                        label="💾 Download ",
                        data=clean_code,
                        file_name=file_name,
                        mime=mime_type,
                        use_container_width=True
                    )
                with cols[2]:
                    if st.button("🧠 Refine", use_container_width=True):
                        st.session_state.refine_chat = True
                        st.session_state.mod_pipeline_chat_open = False
                        st.rerun()
                with cols[4]:
                    if st.button("✨ Connect", use_container_width=True):
                        st.session_state.mod_pipeline_chat_open = True
                        st.session_state.refine_chat = False

                if st.session_state.refine_chat:
                    expert_show()


                if st.session_state.mod_pipeline_chat_open:
                    cols =st.columns([4,1,1,1,1,1,0.5])
                    with cols[0]:
                        st.markdown("### ✨ Connect with the Agent")
                    with cols[6]:
                        if st.button("❌", use_container_width=True):
                            st.session_state.mod_pipeline_chat_open = False
                            st.session_state.mod_chat_history = []
                    #st.markdown("### ✨ Connect with the Agent")

                    # Suggestions
                    suggestions = [
                        "Explain the pipeline",
                        "Give Setup Instructions",
                        "Add deployment to AWS",
                        "Explain each stage with comments",
                        "Add security scan",
                        "Review and optimize pipeline"
                    ]
                    selected_suggestion = st.selectbox("Quick Suggestions", [""] + suggestions)
                    user_mod_input = st.text_area("💬 Ask the Agent to review or modify the code", value=selected_suggestion, key="user_mod_input_area")

                    if st.button("🔁 Ask"):
                        original_code = st.session_state.pipeline_code
                        #last_response = st.session_state.mod_chat_history[-1]['response'] if st.session_state.mod_chat_history else st.session_state.pipeline_code
                        chat_history = st.session_state.mod_chat_history
                        with st.spinner("Agent is processing your input..."):
                            response = llm_rerun(original_code, chat_history, user_mod_input)
                            st.session_state.mod_chat_history.append({
                                "user": user_mod_input,
                                "response": response
                            })
                        st.rerun()

                for i, chat in enumerate(st.session_state.mod_chat_history):
                    st.markdown(f"#### 🧑‍💻 You: {chat['user']}")
                    with st.expander(f"🤖 Response {i+1}", expanded=True):
                        if "```" in chat['response']:  # If it includes code
                            code_match = re.search(r"```(?:yaml|json|[\w]*)\n(.*?)```", chat['response'], re.DOTALL)
                            code_only = code_match.group(1).strip() if code_match else chat['response']
                            st.code(code_only, language="yaml")

                            # Optional download
                            st.download_button(
                                label="📥 Download This Version",
                                data=code_only,
                                file_name=f"modified_version_{i+1}.yml",
                                mime="text/yaml",
                                key=f"download_mod_{i+1}"
                            )
                        else:
                            st.markdown(chat['response'])



    # elif st.session_state.input_method == "file":
    # # Step Content
    #     if st.session_state.step == 1:
    #         st.write("#### Upload your Technical Design Document:")
    #         uploaded_file = st.file_uploader("Choose a .docx file", type=[".docx"])
    #         if uploaded_file is not None:
    #             try:
    #                 file_name = uploaded_file.name
    #                 doc = docx.Document(uploaded_file)
    #                 docx_content = []
    #                 for para in doc.paragraphs:
    #                     docx_content.append(para.text)
    #                 docx_content = "\n\n".join(docx_content)
    #                 if docx_content:
    #                     st.session_state['docx_content_from_step1'] = docx_content
    #                     st.session_state['docx_file_name_step1'] = file_name
    #                     st.write("#### Docx Preview:")
    #                     st.code(docx_content, language="markdown")
    #                     st.session_state.json_spec_generated = True
    #                 else:
    #                     st.info("Uploaded document appears to be empty.")
    #             except Exception as e:
    #                 st.error(f"Error reading DOCX file: {e}")
    #                 if 'json_spec_generated' in st.session_state:
    #                     del st.session_state.json_spec_generated

    #     elif st.session_state.step == 2:
    #         st.header("Step 2: Review JSON Spec & Generate jenkins Pipeline")
    #         st.write("### Generated JSON Specification:")
    #         st.info("After Review Click Generate to generate the Jenkinse spec file.")
    #         json_spec_to_display = st.session_state.get('generated_json_spec')
    #         if json_spec_to_display:
    #             st.markdown(json_spec_to_display)
    #             st.success("JSON Specification ready for review.")
    #         else:
    #             st.error("JSON Specification not found.")
    #             st.warning("Please go back to Step 1 and generate the specification.")

    #     elif st.session_state.step == 3:
    #         st.header("Step 3: Jenkins File Review & Deploy.")
    #         jenkins_spec_to_display = st.session_state.get('generated_jenkins_spec')
    #         if jenkins_spec_to_display:
    #             st.markdown(jenkins_spec_to_display)
    #             st.success("Jenkins Pipeline ready for Review and Download. Click Download to Save the CICD pipeline JSON file.")
    #         else:
    #             st.error("Jenkins Pipeline file not found.")
    #             st.warning("Please go back to Step 2 and generate the File.")

    # # Navigation Buttons
    #     st.write("---")
    #     cols = st.columns([1, 5, 1])
    #     total_steps = 3

    #     with cols[0]:
    #         is_disabled_prev = st.session_state.step <= 1
    #         if st.button("Previous", disabled=is_disabled_prev):
    #             if not is_disabled_prev:
    #                st.session_state.validation_error = None
    #                st.session_state.step -= 1
    #                st.rerun()

    #     with cols[2]:
    #         current_step = st.session_state.step
    #         button_label = "Generate" if current_step < total_steps else "Download"

    #         if current_step == total_steps:
    #             jenkins_data = st.session_state.get("generated_jenkins_spec", "")
    #             data_test = {"jenkins":"data"}
    #             data_for_download_str = json.dumps(data_test, indent=4)
    #             st.download_button(
    #                 label="Download",
    #                 data=data_for_download_str,
    #                 file_name="data.json",
    #                 mime="application/json",
    #                 key="download_button",
    #             )
    #             if jenkins_data:
    #                 st.success("Processing Complete! Click the button above to download.")
     
    #         if (current_step < total_steps) and (current_step != total_steps):
    #             if (st.button(button_label)):
    #                     proceed = False
    #                     error_message = None
    #                     if st.session_state.step == 1:
    #                         if st.session_state.get('json_spec_generated'): 
    #                             try:
    #                                 with st.spinner("Generating JSON Specification..."):
    #                                     json_spec_result = spec_gen(st.session_state.docx_content_from_step1, st.session_state.docx_file_name_step1)
    #                                 st.session_state.generated_json_spec = json_spec_result
    #                                 proceed = True
    #                             except Exception as e:
    #                                 st.error(f"Failed to generate JSON spec: {e}")
    #                                 error_message = f"Failed to generate JSON spec: {e}"
    #                         else: 
    #                             error_message = "Please Upload the TDD."
                        
    #                     elif st.session_state.step == 2:
    #                         if 'generated_json_spec' in st.session_state:
    #                             json_spec_to_process = st.session_state.get('generated_json_spec')
    #                             generated_jenkins_res = generate_jenkins_from_json_spec(json_spec_to_process)
    #                             st.session_state.generated_jenkins_spec = generated_jenkins_res
    #                             proceed = True
    #                         else:
    #                             error_message = "JSON Spec missing. Please go back to Step 1."

    #                     elif st.session_state.step == 3:
    #                         if "generated_jenkins_spec" in st.session_state:
    #                             proceed = True

    #                     if proceed and st.session_state.step < total_steps:
    #                         st.session_state.validation_error = None
    #                         st.session_state.step += 1
    #                         st.rerun()
    #                     elif proceed and st.session_state.step == total_steps:
    #                         st.session_state.validation_error = None
    #                         st.session_state.finished = True
    #                         st.success("Processing Complete!")
    #                         st.rerun()
    #                     else:
    #                         st.session_state.validation_error = error_message
    #                         st.rerun()

    #     if 'validation_error' in st.session_state and st.session_state.validation_error:
    #         st.error(st.session_state.validation_error)