﻿import streamlit as st
import Home
import DevXGenApp
import DevXConApp
import RefinerApp
# Set Streamlit config
st.set_page_config(page_title="DevXcelerate", page_icon="</>", layout="wide")
#st.set_page_config(layout="wide")
st.markdown("""
<style>
    .stApp{
        padding-top: 0px;
        margin-top: -75px;
    }
    header {
        height: 0px !important;
        }
    /* Narrow text area */
    .narrow-textarea textarea {
        max-height: 50px !important;
    }
    /* Step container */
    .step-container {
        display: flex;
        justify-content: space-between;
        margin-bottom: 2rem;
    }
    .step {
        display: flex;
        flex-direction: column;
        align-items: center;
        cursor: pointer;
    }
    .step-number {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background-color: #ddd;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 0.5rem;
    }
    .step-label {
        font-size: 0.8rem;
        text-align: center;
    }
    .active .step-number {
        background-color: #1195CE;
        color: white;
    }
    .completed .step-number {
        background-color: #4CAF50;
        color: white;
    }
    .disabled .step-number {
        background-color: #f0f0f0;
        color: #aaa;
    }
    /* File uploader */
    .file-uploader {
        margin-top: 1rem;
        border: 2px dashed #ccc;
        padding: 1rem;
        border-radius: 5px;
    }
    /* Main content */
    .main-content {
        padding-left: 2rem;
    }
    div.stDownloadButton > button {
            color: white !important;
            background-color: #33374B;
            border: none;
            }
    div.stDownloadButton > button:focus {
            color: white !important;
            background-color: #1195CE;
            border: none;
            }
    div.stDownloadButton > button:hover {
            background-color: #1195CE;
            color: white !important;
            }
    div.stButton > button {
            color: white !important;
            background-color: #33374B;
            border: none;
            }
    div.stButton > button:focus {
            color: white !important;
            background-color: #1195CE;
            border: none;
            }
    div.stButton > button:hover {
            background-color: #1195CE;
            color: white !important;
            }
    /* Feature cards */
    .feature-card {
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        background-color: transparent;
    }
        /* === Make st.code block scrollable ß=== */
    div[data-testid="stCode"] pre {
        max-height: 300px;  /* Adjust this height (e.g., 400px, 500px) */
        overflow-y: auto;
        overflow-x: auto; /* Optional for horizontal scroll */
    }
    @media (prefer-color-scheme: light) {
            body, .step-label, .stApp{
                 color: black !important;
            }
            .feature-card {
                 background-color: #f5f5f5 !important;
            }
        }
    button:hover, button:focus,
    input:hover, input:focus,
            textarea:hover, textarea:focus,
            select:hover, select:focus{
            border: none !important;
            outline: none !important;
            box-shadow: none !important;
            }
    section[data-testid="stSidebar"]{
            background-color: #33374B !important;
            }

</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'current_page' not in st.session_state:
    st.session_state.current_page = "Home"

# Sidebar navigation
with st.sidebar:
    st.markdown("# DevXcelerate")
    st.markdown("---")

    if st.button("🏠 Home"):
        st.session_state.current_page = "Home"
        st.rerun()
    
    if st.button("🪄 Pipeline Generator"):
        st.session_state.current_page = "DevX Generator"
        st.session_state.active_step = 1
        st.session_state.extracted_data = None
        st.session_state.specification = None
        st.session_state.pipeline_code = None
        st.session_state.input_method = "text"
        st.session_state.user_input = ""
        st.rerun()
   
    if st.button("🔁 Pipeline Converter"):
        st.session_state.current_page = "DevX Converter"
        st.session_state.page = 1
        st.session_state.conversion_output = None
        st.session_state.file_content = None
        st.session_state.final_code = None
        st.session_state.file_content = None
        st.rerun()

    if st.button("🧠 Pipeline Refiner"):
        st.session_state.current_page = "DevX Refiner"
        st.session_state.page = 1
        st.session_state.conversion_output = None
        st.session_state.file_content = None
        st.session_state.final_code = None
        st.session_state.file_content = None
        st.rerun()

# Main content routing
if st.session_state.current_page == "Home":
    Home.show()
elif st.session_state.current_page == "DevX Generator":
    DevXGenApp.show()
elif st.session_state.current_page == "DevX Converter":
    DevXConApp.show()
elif st.session_state.current_page == "DevX Refiner":
    RefinerApp.show()
