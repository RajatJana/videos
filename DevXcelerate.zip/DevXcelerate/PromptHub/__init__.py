def load_prompt(filename):
    with open(f"PromptHub/{filename}", "r", encoding='utf-8') as file:
        return file.read()