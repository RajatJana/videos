from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings

# Load FAISS index
embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
vectorstore = FAISS.load_local(
    "pipeline_faiss_index",
    embedding_model,
    allow_dangerous_deserialization=True
)

# Always include security section (using tag/heading match)
def get_security_best_practices():
    all_docs = vectorstore.docstore._dict.values()
    for doc in all_docs:
        title_parts = list(doc.metadata.values())
        if any("security" in str(part).lower() for part in title_parts):
            return {
                "intent": "Security Best Practices",
                "content": doc.page_content,
                "metadata": doc.metadata
            }
    return None

# Flexible semantic search with fallback
def search_semantic_matches(user_intents: list[str], k: int = 1) -> list:
    results = []
    for intent in user_intents:
        intent = intent.strip()
        if not intent:
            continue
        docs = vectorstore.similarity_search(intent, k=k)
        for doc in docs:
            results.append({
                "intent": intent,
                "content": doc.page_content,
                "metadata": doc.metadata
            })

    # Add Security Best Practices always
    sec = get_security_best_practices()
    if sec:
        results.append(sec)

    return results

# Input from user (can be from Gemini earlier step)
user_input = """
Build Maven Azure DevOps
Build Maven Jenkins
Dockerize Docker Azure DevOps
Dockerize Docker Jenkins
Deploy AzureKeyVault Azure DevOps
Deploy AzureKeyVault Jenkins
Deploy Helm Azure DevOps
Deploy Helm Jenkins
Deploy Tomcat Jenkins  
Deploy Tomcat Azure  
Testing Junit Azure
"""

user_intents = user_input.strip().split('\n')
retrieved = search_semantic_matches(user_intents)

# ✅ Display results
for match in retrieved:
    print(f"\n🔍 Intent: {match['intent']}")
    print(f"📝 Metadata: {match['metadata']}")
    print(f"➡️ Content:\n{match['content']}")