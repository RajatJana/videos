import os
import shutil
import tempfile
import git
import google.generativeai as genai
from PromptHub import load_prompt

# ====== CONFIG ======
genai.configure(api_key="AIzaSyApsAGYqoenhbUQ0Zw2tgzMWU_T-IaNHaQ")  # <-- Replace with your actual API key
model = genai.GenerativeModel("gemini-2.0-flash")

# ====== STEP 1: Connect with Agent ======
def llm_rerun(code, chat_history, user_input):

    chat_log = ""
    for turn in chat_history:
        chat_log += f"User: {turn['user']}\n"
        chat_log += f"LLM: {turn['response']}\n\n"

    template = load_prompt("llm_rerun_prompt.txt")
    prompt = template.format(code=code, chat_log=chat_log, user_input=user_input)
    response = model.generate_content(prompt)
    return response.text