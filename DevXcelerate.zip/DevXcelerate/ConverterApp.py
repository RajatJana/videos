import streamlit as st
import asyncio
from Pipeline_Converter import run_conversion  # Backend handler

# 🎛️ UI Inputs
st.title("🔧 Pipeline Converter")

input_tech = st.selectbox("Source Technology", ["Azure DevOps YAML", "Jenkins"])
output_tech = st.selectbox("Target Technology", ["Jenkins", "Azure DevOps YAML"])
input_pipeline = st.text_area("Paste your pipeline YAML here")

submit = st.button("Convert Pipeline")

if submit and input_pipeline.strip():
    with st.spinner("🚀 Converting..."):
        try:
            # Create async loop and call backend conversion
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            converted = loop.run_until_complete(
                run_conversion(
                    source_tech=input_tech,
                    target_tech=output_tech,
                    pipeline_code=input_pipeline
                )
            )

            st.success("✅ Conversion completed!")
            st.code(converted, language="yaml")

        except Exception as e:
            st.error(f"❌ Conversion failed: {e}")