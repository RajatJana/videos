import streamlit as st
import asyncio
import re
from agentlogic import PipelineRefiner

def show():
    """Main function to display the Expert App interface"""
    # Custom CSS for Claude-like interface
    st.markdown("""
    <style>
        /* Main container styling */
        .main-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Chat container */
        .chat-container {
            max-height: 600px;
            overflow-y: auto;
            padding: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            background: #fafafa;
            margin-bottom: 20px;
        }
        
        /* Message boxes */
        .message-box {
            margin: 15px 0;
            padding: 16px;
            border-radius: 12px;
            border: 2px solid;
            background: transparent;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            position: relative;
        }
        
        /* Agent specific styling */
        .devops-message {
            border-color: #3498db;
            background: linear-gradient(135deg, rgba(248, 251, 255, 0.2) 0%, rgba(227, 242, 253, 0.2) 100%);
            margin-right: 100px;
        }
        
        .generator-message {
            border-color: #f39c12;
            background: linear-gradient(135deg, rgba(255, 253, 247, 0.2) 0%, rgba(255, 243, 205, 0.2) 100%);
            margin-right: 100px;
        }
        
        .user-message {
            border-color: #e74c3c;
            background: linear-gradient(135deg, rgba(255, 245, 245, 0.2) 0%, rgba(255, 235, 238, 0.2) 100%);
            margin-left: 100px;
            text-align: right;
        }
        
        /* Agent name styling */
        .agent-name {
            font-weight: bold;
            font-size: 14px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .devops-name {
            color: #2980b9;
        }
        
        .generator-name {
            color: #e67e22;
        }
        
        .user-name {
            color: #c0392b;
            justify-content: flex-end;
        }
        
        /* Typing animation */
        .typing-animation {
            display: inline-block;
        }
        
        .typing-dot {
            height: 8px;
            width: 8px;
            border-radius: 50%;
            background-color: #3498db;
            display: inline-block;
            margin: 0 1px;
            animation: typing 1.4s infinite ease-in-out;
        }
        
        .typing-dot:nth-child(1) { animation-delay: -0.32s; }
        .typing-dot:nth-child(2) { animation-delay: -0.16s; }
        
        @keyframes typing {
            0%, 80%, 100% { transform: scale(0.8); opacity: 0.5; }
            40% { transform: scale(1); opacity: 1; }
        }
    </style>
    """, unsafe_allow_html=True)

    # Initialize session state if not exists
    if "expert_messages" not in st.session_state:
        st.session_state.expert_messages = []
    if "expert_refiner" not in st.session_state:
        st.session_state.expert_refiner = None
    if "expert_stream" not in st.session_state:
        st.session_state.expert_stream = None
    if "expert_feedback_phase" not in st.session_state:
        st.session_state.expert_feedback_phase = False
    if "expert_approved" not in st.session_state:
        st.session_state.expert_approved = False
    if "expert_waiting_for_agents" not in st.session_state:
        st.session_state.expert_waiting_for_agents = False

    cols =st.columns([5,1,1,1,1,0.5,0.5])
    with cols[0]:
        # Title
        st.markdown("<h2 style='color: #1195CE;'>🔍 Pipeline Refinement</h2>", unsafe_allow_html=True)
    with cols[6]:
        if st.button("❌", use_container_width=True):
            st.session_state.refine_chat = False
    with cols[5]:
        if st.button("🔄", use_container_width=True):
            st.session_state.expert_refiner = False
            st.session_state.expert_messages = []
            st.session_state.expert_stream = False
            st.session_state.expert_feedback_phase = False         
            st.session_state.expert_approved = False
            st.session_state.expert_waiting_for_agents = False  

    # Start refinement if we have pipeline content but no refiner yet
    if st.session_state.pipeline_code and not st.session_state.expert_refiner:
        # Extract clean code from markdown if needed
        match = re.search(r"```(?:yaml|json|[\w]*)\n(.*?)```", st.session_state.pipeline_code, re.DOTALL)
        if match:
                clean_code = match.group(1).strip()
        else:
                clean_code = st.session_state.pipeline_code

        refiner = PipelineRefiner(clean_code)
        st.session_state.expert_refiner = refiner
        st.session_state.expert_messages = []
        st.session_state.expert_feedback_phase = False
        st.session_state.expert_approved = False
        st.session_state.expert_waiting_for_agents = True
        st.session_state.expert_stream = asyncio.run(refiner.start_session())
        st.rerun()

    # Display chat history
    for author, text in st.session_state.expert_messages:
        if author == "DevOpsExpert":
            st.markdown(f"""
            <div class="message-box devops-message">
                <div class="agent-name devops-name">🔧 DevOps Expert</div>
                <div>{text}</div>
            </div>
            """, unsafe_allow_html=True)
        elif author == "GeneratorAgent":
            st.markdown(f"""
            <div class="message-box generator-message">
                <div class="agent-name generator-name">⚡ Generator Agent</div>
                <div>{text}</div>
            </div>
            """, unsafe_allow_html=True)
            # Extract the code from the response (assuming it contains markdown with code blocks)
            code_match = re.search(r"```(?:yaml|json|[\w]*)\n(.*?)```", text, re.DOTALL)
            updated_output = code_match.group(1).strip() if code_match else text
        elif author == "System":
            st.markdown(f"""
            <div class="message-box devops-message">
                <div class="agent-name devops-name">🤖 System</div>
                <div>{text}</div>
            </div>
            """, unsafe_allow_html=True)
        elif author == "user":
            st.markdown(f"""
            <div class="message-box user-message">
                <div class="agent-name user-name">👤 You</div>
                <div>{text}</div>
            </div>
            """, unsafe_allow_html=True)

    async def process_agent_responses():
        """Process agent responses with typing animation"""
        try:
            round_buffer = []
            
            async for event in st.session_state.expert_stream:
                if hasattr(event, "content") and event.content:
                    # Handle both parts-based and direct text content
                    if hasattr(event.content, "parts"):
                        text = " ".join(p.text for p in event.content.parts if hasattr(p, "text") and p.text)
                    else:
                        text = str(event.content)
                    
                    if text:
                        author = getattr(event, "author", "assistant")
                        # Normalize agent names exactly like terminal version
                        if "devops" in author.lower():
                            author = "DevOpsExpert"
                        elif "generator" in author.lower():
                            author = "GeneratorAgent"
                        else:
                            author = "System"
                        
                        st.session_state.expert_messages.append((author, text))
                        round_buffer.append((author, text))

                        # After a full round (Generator + DevOps), switch to feedback
                        if len(round_buffer) == 2:
                            st.session_state.expert_feedback_phase = True
                            st.session_state.expert_waiting_for_agents = False
                            round_buffer.clear()
                            break
            
            # If stream ends without 2 responses
            if not st.session_state.expert_feedback_phase:
                st.session_state.expert_feedback_phase = True
                st.session_state.expert_waiting_for_agents = False
                
        except Exception as e:
            st.error(f"Error processing agent responses: {str(e)}")
            st.session_state.expert_stream = None
            st.session_state.expert_feedback_phase = True
            st.session_state.expert_waiting_for_agents = False

    # Process agent responses if waiting
    if st.session_state.expert_waiting_for_agents and st.session_state.expert_stream:
        # Show typing animation while processing
        with st.empty():
            st.markdown("""
            <div class="message-box devops-message">
                <div class="agent-name devops-name">🤖 AI Agents</div>
                <div class="typing-animation">
                    Executing Agents...Please Wait<span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        asyncio.run(process_agent_responses())
        st.rerun()

    # Feedback Phase with buttons (only show when ready for feedback)
    if (st.session_state.expert_feedback_phase and 
        not st.session_state.expert_approved and 
        not st.session_state.expert_waiting_for_agents and 
        st.session_state.expert_refiner):
        
        # Show buttons for quick actions
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("✅ Finalize Pipeline", type="primary", use_container_width=True):
                st.session_state.expert_messages.append(("user", "✅ Approved"))
                st.session_state.expert_approved = True
                st.session_state.expert_feedback_phase = False
                st.session_state.expert_stream = None
                
                # Show confirmation dialog for replacing the pipeline
                st.session_state.show_replace_dialog = True
                st.rerun()
        
        with col2:
            if st.button("⏭️ Continue Refinement", type="secondary", use_container_width=True):
                st.session_state.expert_messages.append(("user", "⏭️ Continue"))
                st.session_state.expert_feedback_phase = False
                st.session_state.expert_waiting_for_agents = True
                st.session_state.expert_stream = asyncio.run(st.session_state.expert_refiner.user_feedback("continue"))
                st.rerun()
        
        # Chat input for custom feedback
        feedback = st.chat_input("💬 Your feedback (or use buttons above):")
        
        if feedback and feedback.strip():
            # Process user feedback
            st.session_state.expert_messages.append(("user", feedback))
            st.session_state.expert_feedback_phase = False
            st.session_state.expert_waiting_for_agents = True
            st.session_state.expert_stream = asyncio.run(st.session_state.expert_refiner.user_feedback(feedback))
            st.rerun()

    # Show replace confirmation dialog if approved
    if st.session_state.get('expert_approved') and st.session_state.get('show_replace_dialog'):
        st.success("✅ Pipeline approved!")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔄 Replace Original Pipeline", type="primary", use_container_width=True):
                # Get the final refined pipeline from the refiner
                #final_pipeline = st.session_state.expert_refiner.get_final_pipeline()
                st.session_state.pipeline_code = updated_output
                st.session_state.refine_chat = False
                st.session_state.show_replace_dialog = False
                st.rerun()
        
        with col2:
            if st.button("✖️ Keep Original Pipeline", type="secondary", use_container_width=True):
                st.session_state.refine_chat = False
                st.session_state.show_replace_dialog = False
                st.rerun()