# CI/CD Pipeline Standards Documentation

## 🔒 Security Best Practices (All Platforms)
- **Credentials Management**:
  - Use secure storage (Azure Key Vault, Jenkins Credentials)
  - Never hardcode secrets
  - Rotate credentials regularly
- **Access Control**:
  - Enforce RBAC on pipelines and agents
  - Use least privilege principle
- **Build Security**:
  - Validate dependencies (OWASP Dependency Check)
  - Version-lock all tools
  - Keep build agents patched
- **Auditing**:
  - Log all pipeline activities
  - Monitor for anomalous behavior

## 🛠️ Build Stage

### 🔨 Maven
#### Jenkins
```groovy
stage('Build') {
  steps {
    sh 'mvn clean install -DskipTests'
    // Cache .m2/repository for performance
  }
}
```
**Security**:  
- Use specific JDK version via Jenkins tool config
- Store Maven settings.xml securely

#### Azure DevOps
```yaml
- task: Maven@3
  inputs:
    mavenPomFile: 'pom.xml'
    goals: 'clean install -DskipTests'
    javaHomeOption: 'JDKVersion'
    jdkVersionOption: '1.8'
```

### 📦 Gradle
#### Jenkins
```groovy
stage('Build') {
  steps {
    sh './gradlew clean build -x test'
  }
}
```
**Security**:  
- Always use Gradle wrapper (./gradlew)
- Store credentials in Jenkins Credentials Store

#### Azure DevOps
```yaml
- task: Gradle@2
  inputs:
    gradleWrapperFile: 'gradlew'
    tasks: 'clean build -x test'
```

### 🐳 Docker Build
#### Jenkins/Azure
```bash
docker build -t $DOCKER_IMAGE:$BUILD_ID .
```
**Security**:  
- Use multi-stage builds
- Scan images for vulnerabilities
- Avoid `--no-cache` in production

## 🚀 Deploy Stage

### 🐈 Tomcat Deployment
#### Jenkins
```groovy
stage('Deploy to Tomcat') {
  steps {
    withCredentials([sshUserPrivateKey(credentialsId: 'tomcat_ssh_key', keyFileVariable: 'KEYFILE')]) {
      sh '''
        scp -i $KEYFILE target/*.war user@server:/opt/tomcat/webapps/
        ssh -i $KEYFILE user@server "sudo systemctl restart tomcat"
      '''
    }
  }
}
```

#### Azure DevOps
```yaml
- task: CopyFilesOverSSH@0
  inputs:
    sshEndpoint: 'tomcatSSHService'
    sourceFolder: '$(System.DefaultWorkingDirectory)/target'
    contents: '**/*.war'
    targetFolder: '/opt/tomcat/webapps/'
- task: SSH@0
  inputs:
    sshEndpoint: 'tomcatSSHService'
    runOptions: 'commands'
    commands: 'sudo systemctl restart tomcat'
```

## 📦 Docker Operations

### 🔼 Push Image
#### Jenkins
```bash
docker login -u $DOCKER_USER -p $DOCKER_PASS $DOCKER_REGISTRY
docker push $DOCKER_IMAGE:$BUILD_ID
docker push $DOCKER_IMAGE:latest
```

#### Azure DevOps
```yaml
- task: Docker@2
  inputs:
    command: push
    tags: '$(Build.BuildId),latest'
```

### ▶️ Run Container
```bash
docker run -d -p 8080:8080 --name app_container $DOCKER_IMAGE:$BUILD_ID
```
**Best Practice**: Include healthcheck in Dockerfile

## 🧪 Quality Gates

### 🔍 SonarQube Analysis
#### Jenkins
```bash
mvn sonar:sonar -Dsonar.projectKey=my-project -Dsonar.host.url=http://localhost:9000 -Dsonar.login=$SONAR_TOKEN
```

#### Azure DevOps
```yaml
- task: SonarQubePrepare@5
- task: Maven@3
  inputs:
    goals: 'sonar:sonar'
- task: SonarQubePublish@5
```

### 🧪 Testing (JUnit)
#### Jenkins
```groovy
stage('Test') {
  steps {
    sh 'mvn test'
    junit '**/target/surefire-reports/*.xml'
  }
}
```

#### Azure DevOps
```yaml
- task: Maven@3
  inputs:
    goals: 'test'
- task: PublishTestResults@2
  inputs:
    testResultsFiles: '**/surefire-reports/*.xml'
```

## 🏗️ Pipeline Best Practices
- **Immutable Builds**: Don't rebuild artifacts across environments
- **Fail Fast**: Use `set -e` or equivalents
- **Parallelism**: Run independent stages in parallel
- **Pipeline as Code**: Store Jenkinsfile/Azure YAML in version control
- **Rollback Plan**: Implement tagging and rollback steps

*Last Updated: June 2025*