import os
import asyncio
from google.adk.agents import LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from DevXConUpdated import DevXConvert

# 🔧 Tool function for pipeline conversion
def convert_pipeline_tool(pipeline_yaml: str, source_tech: str, target_tech: str, input_os: str) -> str:
    print("🔧 In convert_pipeline_tool function")
    print("source_tech:", source_tech)
    print("target_tech:", target_tech)

    converter = DevXConvert()

    if source_tech == "Azure DevOps YAML" and target_tech == "Jenkins":
        return converter.convert_azure_to_jenkins(pipeline_yaml, input_os)
    elif source_tech == "Jenkins" and target_tech == "Azure DevOps YAML":
        return converter.convert_jenkins_to_azure(pipeline_yaml, input_os)
    else:
        raise ValueError(f"Unsupported conversion from {source_tech} to {target_tech}")

# 🤖 Create LLM Agent using the tool function
def create_pipeline_converter_agent():
    return LlmAgent(
        name="PipelineConverterAgent",
        model="gemini-2.0-flash",
        tools=[convert_pipeline_tool],
        instruction=(
            "You convert CI/CD pipelines from one technology to another. "
            "Display the converted pipeline code. Always explain your changes clearly."
        )
    )

# 🧠 Run the conversion asynchronously
async def run_conversion(source_tech: str, target_tech: str, pipeline_code: str, input_os: str) -> str:
    print(f"🔧 Starting conversion from {source_tech} to {target_tech}")

    agent = create_pipeline_converter_agent()
    session_service = InMemorySessionService()

    user_id = "conversion_user"
    session_id = "session_" + os.urandom(4).hex()
    app_name = "pipeline_converter_refiner_app"

    await session_service.create_session(
        user_id=user_id,
        session_id=session_id,
        app_name=app_name
    )

    prompt = types.Content(
        role="user",
        parts=[
            types.Part(
                text=(
                    # f"Please convert this pipeline from {source_tech} to {target_tech}:\n\n{pipeline_code}\n\n"
                    # "Explain any major changes briefly, then show the full converted pipeline wrapped in triple backticks like ```yaml. "
                    # "Use the correct syntax formatting for the target technology."
                    f"Call the function `convert_pipeline_tool` to convert this pipeline "
            f"from {source_tech} to {target_tech}:\n\n{pipeline_code}\n\nOS: {input_os}"
            "Keep the source_tech and target_tech name as it is"
            "Return the converted code only"
                )
            )
        ]
    )

    
    runner = Runner(agent=agent, session_service=session_service, app_name=app_name)
    generator = runner.run_async(user_id=user_id, session_id=session_id, new_message=prompt)

    converted_output = ""
    async for event in generator:
        if event.content and event.content.parts:
            for part in event.content.parts:
                if hasattr(part, "text") and part.text:
                    converted_output += part.text + "\n"
                elif hasattr(part, "function_call"):
                    print("📦 Function call detected")

    return converted_output.strip()