# logic.py

import os
import asyncio
from google.adk.agents import LlmAgent, LoopAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

os.environ["GOOGLE_API_KEY"] = "AIzaSyApsAGYqoenhbUQ0Zw2tgzMWU_T-IaNHaQ"  # Replace securely

class PipelineRefiner:
    def __init__(self, pipeline_code):
        self.pipeline_code = pipeline_code
        self.session = InMemorySessionService()
        self.transcript = []
        self.generator = LlmAgent(
            name="GeneratorAgent",
            model="gemini-2.0-flash",
            instruction=("Pass the initial file to DevOpsExpert for feedback.Always pass user feedback to DevOpsExpert for analysis. Don't provide initial feedback. Always prioritize EndUserAgent feedback. Stop when 'approved'."
                         "Take user feedback and update the pipeline"
                         "Then send the new version to DevOpsExpert for review."
                         "Continue this loop until the user types 'approved'")
        )
        self.devops = LlmAgent(
            name="DevOpsExpert",
            model="gemini-2.0-flash",
            instruction="Review pipelines and suggest improvements. Stop when user approves. Always respond when Generator sens an update"
        )
        self.loop = LoopAgent(
            name="PipelineRefinementLoop",
            sub_agents=[self.generator, self.devops],
            max_iterations=20
        )
        self.runner = Runner(
            agent=self.loop,
            session_service=self.session,
            app_name="ci_cd_pipeline_refiner"
        )
        self.session_id = "session-001"
        self.user_id = "ci-user"

    async def start_session(self):
        await self.session.create_session(
            app_name="ci_cd_pipeline_refiner",
            user_id=self.user_id,
            session_id=self.session_id
        )
        content = types.Content(
            role="user",
            parts=[types.Part(text=f"Initial pipeline draft:\n\n{self.pipeline_code}")]
        )
        return self.runner.run_async(
            user_id=self.user_id,
            session_id=self.session_id,
            new_message=content
        )

    async def user_feedback(self, feedback):
        user_message = types.Content(
            role="user",
            parts=[types.Part(text=feedback)]
        )
        return self.runner.run_async(
            user_id=self.user_id,
            session_id=self.session_id,
            new_message=user_message
        )